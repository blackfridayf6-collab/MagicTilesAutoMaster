package com.magictiles.automaster

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var hitLineInput: EditText
    private lateinit var status: TextView
    private val projectionManager by lazy {
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF10101A.toInt())
        }

        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
            }

        root.addView(text("MAGIC TILES", 15f, 0xFFB7B7D5.toInt()))
        root.addView(text("AUTO MASTER", 30f, 0xFF65E8FF.toInt()),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 14 })
        root.addView(text("Detecção de 4 faixas • multitoque • modo EXTREME experimental", 14f, 0xFFD7D7E8.toInt()))

        val lineLabel = text("Linha de acionamento (% da altura da tela)", 14f, 0xFFFFFFFF.toInt())
        lineLabel.setPadding(0, 28, 0, 8)
        root.addView(lineLabel)
        hitLineInput = EditText(this).apply {
            setText("93")
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            setBackgroundColor(0xFF29293B.toInt())
            setPadding(12, 8, 12, 8)
        }
        root.addView(hitLineInput, LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 22 })

        val accessibilityButton = Button(this).apply {
            text = "1. ATIVAR ACESSIBILIDADE"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibilityButton, matchWidth())

        val startButton = Button(this).apply {
            text = "2. INICIAR CAPTURA E AUTO"
            setOnClickListener {
                if (!isAccessibilityEnabled()) {
                    status.text = "Ative primeiro o serviço de acessibilidade e volte aqui."
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else {
                    startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE)
                }
            }
        }
        root.addView(startButton, matchWidth())

        val stopButton = Button(this).apply {
            text = "PARAR AUTO PLAYER"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TileCaptureService::class.java))
                status.text = "Auto Player parado."
            }
        }
        root.addView(stopButton, matchWidth())

        status = text("Status: aguardando início", 14f, 0xFFFFD27A.toInt())
        status.setPadding(0, 22, 0, 12)
        root.addView(status)
        root.addView(text(
            "Como usar: ative a acessibilidade, inicie a captura, aceite a permissão do Android e abra o Magic Tiles 3. A captura continua enquanto você troca para o jogo. Mantenha a tela ligada.",
            13f, 0xFFCACADD.toInt()
        ))
        root.addView(text(
            "A detecção inicial procura peças escuras perto da parte inferior. Ajuste a linha se tocar cedo ou tarde. Teste primeiro em uma música lenta.",
            13f, 0xFFFFD27A.toInt()
        ).apply { setPadding(0, 16, 0, 0) })

        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.contains(packageName, ignoreCase = true) }
    }

    @Deprecated("Used for the MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Captura não autorizada."
            return
        }
        val percent = hitLineInput.text.toString().toIntOrNull()?.coerceIn(70, 99) ?: 93
        val serviceIntent = Intent(this, TileCaptureService::class.java).apply {
            putExtra(TileCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(TileCaptureService.EXTRA_RESULT_DATA, data)
            putExtra(TileCaptureService.EXTRA_HIT_LINE, percent / 100f)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
        status.text = "Captura iniciada. Agora abra o Magic Tiles 3."
    }

    companion object { private const val REQUEST_CAPTURE = 4102 }
}
