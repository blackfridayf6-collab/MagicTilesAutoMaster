package com.magictiles.automaster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class TileCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private var hitLine = 0.93f
    private val wasActive = BooleanArray(4)
    private val lastTapMs = LongArray(4)
    private val stopping = AtomicBoolean(false)
    private var screenWidth = 0
    private var screenHeight = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_STICKY

        createNotificationChannel()
        startForegroundCompat()
        hitLine = intent?.getFloatExtra(EXTRA_HIT_LINE, 0.93f)?.coerceIn(0.70f, 0.99f) ?: 0.93f

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            worker = HandlerThread("TileFrameWorker").also { it.start() }
            handler = Handler(worker!!.looper)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture(); stopSelf() }
            }, handler)
            startDisplayCapture()
        } catch (_: Exception) {
            stopCapture()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startDisplayCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        val density = metrics.densityDpi
        if (screenWidth <= 0 || screenHeight <= 0) throw IllegalStateException("Invalid screen size")

        reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = try { source.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) {
                image.use { processFrame(it) }
            }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "MagicTilesAutoMaster", screenWidth, screenHeight, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        ) ?: throw IllegalStateException("Could not create screen capture")
    }

    private fun processFrame(image: Image) {
        if (stopping.get() || image.planes.isEmpty()) return
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val y = (image.height * hitLine).toInt().coerceIn(8, image.height - 9)
        val laneTaps = ArrayList<Int>(4)
        val now = System.currentTimeMillis()
        val offsets = floatArrayOf(0.18f, 0.25f, 0.32f, 0.68f, 0.75f, 0.82f)

        for (lane in 0..3) {
            var dark = 0
            var total = 0
            for (offset in offsets) {
                val x = ((lane + offset) * image.width / 4f).toInt().coerceIn(0, image.width - 1)
                for (dy in -4..4 step 4) {
                    val index = (y + dy) * rowStride + x * pixelStride
                    if (index < 0 || index + 2 >= buffer.limit()) continue
                    val red = buffer.get(index).toInt() and 0xFF
                    val green = buffer.get(index + 1).toInt() and 0xFF
                    val blue = buffer.get(index + 2).toInt() and 0xFF
                    val luminance = (red * 0.2126f + green * 0.7152f + blue * 0.0722f)
                    // The supplied gameplay image shows dark gradient tiles against a brighter background.
                    if (luminance < 105f && (red < 165 || green < 95)) dark++
                    total++
                }
            }
            val fraction = if (total == 0) 0f else dark.toFloat() / total
            val active = fraction >= 0.70f
            if (active && !wasActive[lane] && now - lastTapMs[lane] >= 42L) {
                laneTaps.add(lane)
                lastTapMs[lane] = now
            }
            // Lower release threshold helps re-arm after a tile leaves the scan line.
            if (fraction < 0.14f) wasActive[lane] = false
            else if (active) wasActive[lane] = true
        }

        if (laneTaps.isNotEmpty()) {
            TileTapAccessibilityService.instance?.tapLanes(laneTaps, screenWidth, screenHeight)
        }
    }

    private fun startForegroundCompat() {
        val stopIntent = Intent(this, TileCaptureService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 22, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Magic Tiles Auto Master")
                .setContentText("Detecção e toques automáticos ativos")
                .setOngoing(true)
                .addAction(Notification.Action.Builder(null, "Parar", stopPending).build())
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Magic Tiles Auto Master")
                .setContentText("Detecção e toques automáticos ativos")
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Magic Tiles Auto", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun stopCapture() {
        if (!stopping.compareAndSet(false, true)) return
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { virtualDisplay?.release() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        virtualDisplay = null
        reader = null
        projection = null
        worker?.quitSafely()
        worker = null
        handler = null
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_HIT_LINE = "hit_line_fraction"
        const val ACTION_STOP = "com.magictiles.automaster.STOP"
        private const val CHANNEL_ID = "magic_tiles_auto_channel"
        private const val NOTIFICATION_ID = 4103
    }
}
