package com.magictiles.automaster

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class TileTapAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun tapLanes(lanes: List<Int>, screenWidth: Int, screenHeight: Int) {
        if (lanes.isEmpty()) return
        val builder = GestureDescription.Builder()
        val y = (screenHeight * 0.90f).coerceIn(1f, (screenHeight - 2).toFloat())
        lanes.distinct().forEach { lane ->
            if (lane !in 0..3) return@forEach
            val x = screenWidth * ((lane + 0.5f) / 4f)
            val path = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 1))
        }
        dispatchGesture(builder.build(), null, null)
    }

    companion object {
        @Volatile var instance: TileTapAccessibilityService? = null
            private set
    }
}
