# Magic Tiles Auto Master — Android prototype

Android Studio / Kotlin source project for a four-lane screen detector and accessibility-based tap prototype.

## Current prototype features
- MediaProjection screen capture (Android consent dialog required each session).
- Four-lane sampling based on the supplied portrait gameplay screenshot.
- Multi-lane gestures when more than one lane is detected in the same frame.
- Adjustable vertical scan line (70–99% of screen height; default 93%).
- Foreground notification with a stop action.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Important limitations
This is an initial heuristic detector, not a finished or verified perfect player. It samples dark pixels near one horizontal scan line. It may miss bright/transparent notes, confuse dark background areas with tiles, or mistime notes on fast songs. The screenshot provided shows dark gradient tiles; other themes or effects may need new thresholds and a calibration screen. Test with a slow song first. No 100% accuracy or EXTREME-level performance is promised.

The project was not compiled in this environment because an Android SDK / Gradle installation was unavailable. The included GitHub Actions workflow is intended to compile it after the source is pushed to a repository.

## Build the APK on GitHub
1. Create a new repository named `MagicTilesAutoMaster` under the selected GitHub account.
2. Upload the contents of this folder to the repository root (not the containing folder itself).
3. Open **Actions** and run **Build Android APK**, or push to `main`.
4. Open the completed workflow run and download the `MagicTilesAutoMaster-debug-apk` artifact. It contains `app-debug.apk`.

## Install and use
1. Install the APK on the Android phone.
2. Open the app and enable **Magic Tiles Auto Master** under Android Accessibility settings.
3. Return to the app, choose the scan-line percentage, and tap **Iniciar captura e Auto**.
4. Approve Android's screen-capture prompt.
5. Switch to Magic Tiles 3. Keep the screen on. Use the persistent notification's **Parar** action or reopen the app to stop it.

The accessibility service is used only to dispatch taps. Screen capture uses Android MediaProjection and requires explicit user consent.
